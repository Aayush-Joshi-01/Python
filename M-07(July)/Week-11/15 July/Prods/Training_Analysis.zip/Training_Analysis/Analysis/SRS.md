# grouping with competency
# grouping with skill
# grouping with grades
# grouping with allocation
# grouping with billable
# grouping with project
# grouping with team
# grouping with place
# grouping with training status
# grouping with training type
# grouping with upgraded skills
# grouping with upgraded skill



    
    
# client req
1	Training record based on status(In progress)
2	Training resource count based on traning name.
3	Total training  attended by candidate.
4	Competency wise training attended by  assosiate. (like react, python)
5	Top performer score wise (like, angualar, react, ).
    
    
# our thinking
    
    1: Find out developers skill Competency.
         -> List of skills 
        ->  Show selected skills assosciates.
    2: Associate location wise strenght,
    
    3: Compatency wise strength 
         We can categorise designation wise :
                -> AT
                -> T
                 -> E1  , E2 , E3 
    
    4: Find top assocites skills wise.
    
     5: Training status:
    
           Python Competancy
           Java  Competancy
            AWS 
            React 
            Angual 
    
       -All Active trainig 
       - Month wise training completion.
    
    6:  Final training growth : (pre assesment, Final Assesment)
