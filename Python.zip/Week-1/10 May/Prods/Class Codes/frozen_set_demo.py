animals = frozenset(["cat", "dog", "lion"])
print(type(animals))
print(animals)
