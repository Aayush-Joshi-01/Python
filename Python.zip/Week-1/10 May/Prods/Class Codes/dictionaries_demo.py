values = {'name': ['aayush', 'raounak'], 'phone': ['990121', '123712']}
print(type(values.items()))
print(values.items())
print(values.keys())
print(values.values())
for val in values.items():
    print(type(val))
    print(val)
