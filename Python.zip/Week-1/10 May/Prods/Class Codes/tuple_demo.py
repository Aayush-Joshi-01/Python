# value = (1,2,3,4,5)
# print(type(value))
# print(id(value))
#
# value = ([1,2,3],4,5,6)
# value[0].append(7)
# print(value)

# val = 1,2,3,4
# print(type(val))
# print(val)
# val1, val2, val3, val4 = val
# print(f"{val4}, {val3}, {val2}, {val1}")
# val1, *val2 = val
# print(type(val2))

# print(type(val for val in range(0,11)))
# print(id(val for val in range(0,11)))
