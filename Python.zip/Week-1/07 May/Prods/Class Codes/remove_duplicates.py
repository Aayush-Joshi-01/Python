def remove_duplicate_in_list(list_of_number):
    list_of_number = set(list_of_number)
    list_of_number = list(list_of_number)
    return list_of_number


if __name__ == '__main__':
    print(remove_duplicate_in_list(list_of_number=[1, 2, 3, 4, 5, 1, 12, 4, 5]))
    # removing duplicates using type casting
