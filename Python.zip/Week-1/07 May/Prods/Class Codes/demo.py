# Chaining can be done on relational operators
# print(10<20<50) # True
# print(10<20>30<40<50) # False
# print(10 == 10 == 20 - 10) # True


## in and not in opertator


# my_list = [11,15,21,29,70]
# number = 15
# if number in my_list:
#     print("number is present")
# else:
#     print("number is not present")
# number2 = 51
# if number2 not in my_list:
#     print("number is not present")
# else:
#     print("number is present")


# is and not is

# num1 = 10
# num2 = 10
# num3 = 15
# print(num1 is num2) # True
# print(num1 is not num2) # False
# print(num2 is not num3) # True

# print(id(num1))
# print(id(num2))

# table 1 3 5 7 11  reserved
# veg or nonveg
# table number booked or not
# veg tables are even
# veg table booked are 2 4 6 8 12
# nonveg tables are odd
