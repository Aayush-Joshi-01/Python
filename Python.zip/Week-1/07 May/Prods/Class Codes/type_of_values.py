def type_of(value):
    print(type(value))
    print(id(value))


if __name__ == '__main__':
    number = 10
    type_of(number)
    print(id(number))

    # checking the types of the values

    float_number = 10.5
    type_of(float_number)
    print(id(float_number))

# change the type of value
