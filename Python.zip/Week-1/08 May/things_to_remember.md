# Things to Remember

- ## Listen Carefully
- ## Put your Suggestions
- ## Think About the Logic
- ## Start Working