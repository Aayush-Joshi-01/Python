new = "Hello"
print(new)
new = new + "Worlds"
print(new)
