def reverse_sentence(s):
    return " ".join(s.split(" ")[::-1])


print(reverse_sentence("Hello World and I am Aayush"))
