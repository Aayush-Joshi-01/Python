print('5' == 5)
