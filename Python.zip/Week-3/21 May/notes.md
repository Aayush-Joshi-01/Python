# File Handling in Python

## Pickling

- **dumps, dump**
- **loads, load**

