# Week wise topic breakup

- ## Week 1 (7th May - 10th May)
    - ### Python (Introduction), Strings, Lists, Tuple, Sets, Frozen Sets, Dictionary

---

- ## Week 2 (14th May - 17th May)
    - ### Python Functions, Scope of Variable, Exception Handling, User Defined Exceptions, Exception Chaining, Modules

---

- ## Week 3 (20th May - 24th May)
    - ### Python file handling and Advanced Python
