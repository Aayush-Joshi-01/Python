Instance property deals with instance attributes

