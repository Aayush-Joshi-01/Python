# OOPS

## Scope of Variable in Class

- ### Local Attribute
- ### Class Attribute # main
- ### Instance Attribute # main
- ### Parameter

#### Instance Attribute can be decalared at 3 places inside the constructor inside instance method and outside the reference variable
