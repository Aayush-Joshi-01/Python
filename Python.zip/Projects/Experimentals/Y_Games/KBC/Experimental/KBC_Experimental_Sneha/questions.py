questions = {
    "Which god is known as 'Gauri Nandan'?": [
        "Ganesha", "Agni", "Indra", "Hanuman"
    ],
    "What does not grow on a tree according to a popular Hindi saying?": [
        "Money", "Flowers", "Leaves", "Fruits"
    ],
    "Which city is known as Pink City in India?": [
        "Jaipur", "Bangalore", "Mysore", "Kochi"
    ],
    "Who wrote India's National Anthem?": [
        "Rabindranath Tagore", "Lal Bahadur Shastri", "Chetan Bhagat", \
        "RK Narayan"
    ],
    "How many major religions are there in India?": [
        "6", "7", "8", "9"
    ],
    "When is the National Hindi Diwas celebrated?": [
        "14 September", "13 September", "14 July", "15 August"
    ],
    "How many states are there in India?": [
        "28", "29", "31", "32"
    ],
    "Where in India is the India Gate located?": [
        "New Delhi", "Agra", "Punjab", "Mumbai"
    ],
    "Who wrote Vande Mataram?": [
        "Bankim Chandra Chatterjee", "Sarat Chandra Chattopadhyay", \
        "Rabindranath Tagore", "Ishwar Chandra Vidyasagar"
    ],
    "Which one of the following places is famous for the Great Vishnu Temple?": [
        "Ankorvat, Cambodia", "Bordubar, Indonesia", "Bamiyan, Afghanistan", \
        "Panja Sahib, Pakistan"
    ],
    "The largest Buddhist Monastery in India is located at": [
        "Tawang, Arunachal Pradesh", "Sarnath, Uttar Pradesh", \
        "Dharmashala, Himachal Pradesh", "Gangtok, Sikkim"
    ],
    "Which Indian monument was originally built as a victory tower to commemorate the defeat of the Khan of Khambhat?": [
        "Vijay Stambha", "Qutub Minar", "India Gate", "Charminar"
    ],
    "Who among the following was killed during 'Operation Bluestar' of 1984?": [
        "Jarnail Singh Bhindrawale", "Baba Santa Singh", "Haji Mastan", \
        "Homi Jehangir Bhabha"
    ],
    "Which former Indian President died as a result of a road accident?": [
        "Giani Zail Singh", "Rajendra Prasad", "Fakhruddin Ali Ahmed", \
        "R. Venkatraman"
    ],
    "Who is the founder of the political party Dravida Munnetra Kazhagam (DMK)?": [
        "C.N. Annadurai", "M. Karunanidhi", "M.G. Ramachandran", "Jayalalitha"
    ],
    "Who was the first Indian woman to win a medal in the Olympics?": [
        "Karnam Maleshwari", "P.T. Usha", "Kunjarani Devi", "Bachendri Pal"
    ]
}
