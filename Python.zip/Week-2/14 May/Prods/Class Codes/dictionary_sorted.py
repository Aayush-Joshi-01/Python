dict1 = {'a': 24, 'b': 56, 'c': 25}
print(sorted(dict1))
print(sorted(dict1.keys()))
print(sorted(dict1.values()))
print(dict(sorted(dict1.items())))
