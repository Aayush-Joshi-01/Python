def func() -> tuple:
    print("In the Function")
    return 1, 2


if __name__ == '__main__':
    print(func())
    print(help(func()))
