# Python Training
## Core Python
## Advanced Python
## Python Technologies (Numpy, Pandas, etc,)
## Data Science
## Cloud AWS and Azure
## Data Analytics (PowerBI)